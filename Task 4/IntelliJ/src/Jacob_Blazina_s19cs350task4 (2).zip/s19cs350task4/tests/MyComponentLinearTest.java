package s19cs350task4.tests;

import org.junit.jupiter.api.Test;
import s19cs350task4.MyComponentLinear;

import static org.junit.jupiter.api.Assertions.*;

class MyComponentLinearTests {

    @Test
    void component_initializes_correctly() {
        MyComponentLinear test = new MyComponentLinear("Test ID", 0, 10, 1);

        assertEquals("Test ID", test.getID_());
        assertEquals(0, test.getStateStart_());
        assertEquals(10, test.getStateEnd_());
        assertEquals(1, test.getStep_());
    }

    @Test
    void constructor_id_invalid_string_failure() {
        assertThrows(RuntimeException.class,
                () -> {
                    new MyComponentLinear("", 0, 10, 1);
                });
    }

    @Test
    void updateState_increments_one_step_positive_success() {
        MyComponentLinear test = new MyComponentLinear("Tester", 0.0, 10.0, 1);

        assertEquals(0, test.getState_());

        test.updateState_();

        assertEquals(1, test.getState_());
    }

    @Test
    void updateState_increments_one_step_negative_success() {
        MyComponentLinear test = new MyComponentLinear("Tester", 10.0, 0.0, 1);

        assertEquals(10.0, test.getState_());

        test.updateState_();

        assertEquals(9.0, test.getState_());
    }

    @Test
    void updateState_does_not_reach_stateEnd_returns_false(){
        MyComponentLinear test = new MyComponentLinear("Tester", 10.0, 0.0, 1);

        assertEquals(false, test.updateState_());
    }

    @Test
    void updateState_reaches_stateEnd_returns_true(){
        MyComponentLinear test = new MyComponentLinear("Tester", 0.0, 1.0, 1);

        assertEquals(true, test.updateState_());
    }

    @Test
    void cancel_stops_servicing_updateState_not_at_stateEnd_success(){
        MyComponentLinear test = new MyComponentLinear("Tester", 0.0, 3.0, 1);

        test.updateState_();

        assertEquals(1, test.getState_());

        test.updateState_();

        assertEquals(2, test.getState_());

        test.cancel_();

        test.updateState_();
        test.updateState_();

        assertEquals(2, test.getState_());
        assertEquals(false, test.updateState_());
    }

    @Test
    void cancel_stops_servicing_updateState_at_stateEnd_success(){
        MyComponentLinear test = new MyComponentLinear("Tester", 10.0, 0.0, 1);

        for (int i = 10; i > 1; i--){
            assertEquals(i, test.getState_());
            assertFalse(test.updateState_());
            assertEquals(i - 1, test.getState_());
        }

        assertTrue(test.updateState_());
        assertTrue(test.updateState_());

        assertEquals(0.0, test.getState_());

        assertFalse(test.isDead_());

        test.cancel_();

        assertTrue(test.isDead_());

        assertTrue(test.updateState_());
        assertTrue(test.updateState_());

        assertEquals(0.0, test.getState_());
    }

    @Test
    void updateState_does_not_overstep_endState_success(){
        MyComponentLinear test = new MyComponentLinear("Tester", 0.0, 5.0, 6);

        assertTrue(test.updateState_());
        assertEquals(5, test.getState_());
    }

    @Test
    void terminate_gradually_shuts_down_positive_polarity_success(){
        MyComponentLinear test = new MyComponentLinear("Tester", 0.0, 10.0, 1);

        //4 ticks, then terminate, then should go backwards three more ticks
        test.updateState_();
        assertEquals(1, test.getState_());

        test.updateState_();
        assertEquals(2, test.getState_());

        test.updateState_();
        assertEquals(3, test.getState_());

        test.updateState_();
        assertEquals(4, test.getState_());

        // Call terminate
        test.terminate_();
        assertTrue(test.isDying_());
        assertFalse(test.isDead_());

        // Reverse 1
        test.updateState_();
        assertEquals(3, test.getState_());
        assertTrue(test.isDying_());
        assertFalse(test.isDead_());

        // Reverse 2
        test.updateState_();
        assertEquals(2, test.getState_());
        assertTrue(test.isDying_());
        assertFalse(test.isDead_());

        // Reverse 3, now is dead
        test.updateState_();
        assertEquals(1, test.getState_());
        assertTrue(test.isDying_());
        assertTrue(test.isDead_());

        // Counter is up, now component is Dead
        test.updateState_();
        assertEquals(1, test.getState_());
        assertTrue(test.isDying_());
        assertTrue(test.isDead_());

        test.updateState_();
        assertEquals(1, test.getState_());
        assertTrue(test.isDying_());
        assertTrue(test.isDead_());
    }

    @Test
    void terminate_gradually_shuts_down_negative_polarity_success(){
        MyComponentLinear test = new MyComponentLinear("Tester", 10.0, 0.0, 1);

        //4 ticks, then terminate, then should go backwards three more ticks
        test.updateState_();
        assertEquals(9, test.getState_());

        test.updateState_();
        assertEquals(8, test.getState_());

        test.updateState_();
        assertEquals(7, test.getState_());

        test.updateState_();
        assertEquals(6, test.getState_());

        // Call terminate
        test.terminate_();
        assertTrue(test.isDying_());
        assertFalse(test.isDead_());

        // Reverse 1
        test.updateState_();
        assertEquals(7, test.getState_());
        assertTrue(test.isDying_());
        assertFalse(test.isDead_());

        // Reverse 2
        test.updateState_();
        assertEquals(8, test.getState_());
        assertTrue(test.isDying_());
        assertFalse(test.isDead_());

        // Reverse 3, then sets to dead
        test.updateState_();
        assertEquals(9, test.getState_());
        assertTrue(test.isDying_());
        assertTrue(test.isDead_());

        // Counter is up, now component is Dead
        test.updateState_();
        assertEquals(9, test.getState_());
        assertTrue(test.isDying_());
        assertTrue(test.isDead_());

        test.updateState_();
        assertEquals(9, test.getState_());
        assertTrue(test.isDying_());
        assertTrue(test.isDead_());
    }

}
